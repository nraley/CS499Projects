public class Ramp extends Osc {
    //no need to write anything, Osc already returns a ramp
    //it's abstract though, so we need this class
}
